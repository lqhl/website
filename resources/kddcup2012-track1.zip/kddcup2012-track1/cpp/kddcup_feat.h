#ifndef _KDDCUP_FEAT_H_
#define _KDDCUP_FEAT_H_
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>

inline FILE *fopen_check( const char *fname, const char *flag ){
    FILE *fi = fopen( fname, flag );
    if( fi == NULL ){
        fprintf( stderr, "can't open file %s\n", fname );
        exit( -1 );
    }
    return fi;
}

inline void assert_true( bool exp ){
    if( !exp ){
        fprintf( stderr, "assert error\n" );
        exit( -1 );
    }
}

inline void assert_true( bool exp, const char *s ){
    if( !exp ){
        fprintf( stderr, "assert error:%s\n", s );
        exit( -1 );
    }
}

inline void write_norm_vec( FILE *fo, std::vector<int> gids ){
    fprintf( fo, "%d", (int)gids.size() );
    if( gids.size() > 0 ){
        float inv = 1.0f / sqrtf( gids.size() );
        for( size_t i = 0; i < gids.size(); i ++ ){
            fprintf( fo," %d:%f", gids[i], inv );
        }
    }
    fprintf( fo, "\n" );
}

#endif
