#include "kddcup_feat.h"
#include <vector>
#include <algorithm>

using namespace std;

static const int num_items = 6095;
static const int num_users = 2320895;

int main( int argc, char* argv[] ) {
	if ( argc < 3 ) {
		printf("Usage: input output [mode=0]\n");
		return -1;
	}
    int mode = 0, ngap, nfeat;
    if( argc > 3 ) mode = atoi( argv[3] ); 
    FILE *fi = fopen_check( argv[1], "r" );
    FILE *fo = fopen_check( argv[2], "w" );
    assert_true( fscanf( fi, "%d", &ngap ) == 1 );
    fprintf( fo, "%d\n", mode == 0 ? ngap : ngap - 1 );
    
    while( fscanf( fi, "%d", &nfeat ) == 1 ){
        int ndt;
        std::vector<int> nid;
        for( int i = 0; i < nfeat; i ++ ){
            assert_true( fscanf( fi, "%*d:%d", &ndt ) == 1, "data" ); 
            nid.push_back( ndt );
        }
        if( nfeat != 0 ){
            fprintf( fo, "%d", mode == 0 ? nfeat : nfeat - 1 ); 
            if( mode == 0 ){
                fprintf( fo, " 0:%d", nid[0] );
            }
            for( size_t i = 1; i < nid.size(); i ++ ){
                int idx = mode == 0 ? (int)i: (int)(i-1);
                fprintf( fo, " %d:%d", idx, nid[i] - nid[i-1] ); 
            }
        }else{
            fprintf( fo, "0" );
        }
        fprintf( fo, "\n" );
    }    
    fclose( fi ); fclose( fo );
	return 0;
}
