#include "kddcup_feat.h"
#include "kddcup_spmat.h"
#include <vector>
#include <algorithm>

static const int num_items = 6095;
static const int num_users = 2320895;

SMatrix mfriend;
int nfollow[ num_users ];
using namespace std;

int main( int argc, char *argv[] ) {
	if ( argc < 3 ) {
		printf("usage: <sns.ridx> <out>\n");
		return -1;
	}
    fill( nfollow, nfollow+num_users, 0 );
    int to;
    FILE *fi = fopen_check( argv[1], "r" );
    while( fscanf( fi, "%*d%d", &to ) == 1 ){
        nfollow[ to ] ++;
    }
    fclose( fi );

    vector< pair<int,int> > gdata;
    for( int i = num_items; i < num_users; i ++ ){
        gdata.push_back( make_pair( -nfollow[i],i ) );
    }    
    sort( gdata.begin(), gdata.end());
    FILE *fo = fopen_check( argv[2], "w" );
    for( size_t i = 0; i < gdata.size(); i ++ ){
        int cnt = -gdata[i].first;
        fprintf( fo, "%d\t%d:%f\n", gdata[i].second, cnt, ((float)cnt)/num_users );
    }
    fclose( fo );
	return 0;
}
