#include "kddcup_feat.h"
#include <vector>
#include <algorithm>

using namespace std;

static const int num_items = 6095;
static const int num_users = 2320895;

int main( int argc, char* argv[] ) {
	if ( argc < 4 ) {
		printf("Usage: train.group output len [filter]\n");
		return -1;
	}
    int slen = atoi( argv[3] );
    int uid, tstamp, uuid;
    FILE *fp = NULL;
    FILE *fi = fopen_check( argv[1], "r" );
    FILE *fo = fopen_check( argv[2], "w" );
    if( argc > 4 ){
        fp = fopen_check( argv[4], "r" );
    }
    
    fprintf( fo, "1\n" );
    assert_true( fscanf( fi, "%d%*d%*d%d", &uid, &tstamp ) == 2, "BUG" );
    uuid = uid;

    while( uuid != -1 ){
        vector< int > dtstamp, dts;
        while( uuid == uid ){
            dtstamp.push_back( tstamp );
            if( fp != NULL ){
                int pass;
                assert_true( fscanf( fp, "%d", &pass ) == 1, "BUG" );
                if( pass != 0 ){
                    dts.push_back( tstamp ); 
                }
            }else{
                dts.push_back( tstamp );
            }
            if( fscanf( fi, "%d%*d%*d%d", &uid, &tstamp ) != 2 ){
                uid = -1;
            }
        }
        uuid = uid;
        // make data
        sort( dts.begin(), dts.end() );
        dts.resize( unique( dts.begin(), dts.end() ) - dts.begin() );
        // output previous gap and next gap
        for( size_t i = 0; i < dtstamp.size(); i ++ ){
            int ts = dtstamp[i];
            size_t start  = std::lower_bound( dts.begin(), dts.end(), ts ) - dts.begin();
            size_t end    = std::lower_bound( dts.begin(), dts.end(), ts + slen ) - dts.begin();            
            fprintf( fo, "1 0:%d\n", (int)( end - start ) );
        }
    }
    fclose( fi ); fclose( fo ); 
    if( fp != NULL ) fclose( fp );
	return 0;
}
