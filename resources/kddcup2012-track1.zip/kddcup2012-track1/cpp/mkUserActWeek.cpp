#include "kddcup_feat.h"
#include <vector>
#include <algorithm>

using namespace std;

static const int num_items = 6095;
static const int num_users = 2320895;

int user_hit [ num_users ];
int user_miss[ num_users ];
int user_last[ num_users ];

inline void update( const char *fname, const char *fnamet ){
    FILE *fi = fopen_check( fname, "r" );
    FILE *ft = fopen_check( fnamet, "r" );
    int uid, ts, wk;
    while( fscanf( fi, "%d%*d%*d%d", &uid, &ts ) == 2 ){
        assert_true( fscanf( ft, "%d%*[^\n]\n", &wk ) == 1, "load week" );
        int last = user_last[ uid ];
        user_last[ uid ] = ts;
        if( last == ts ) continue;
        if( wk == 0 || wk == 6 ){
            user_hit[ uid ] ++;
        }else{
            user_miss[ uid ] ++;
        }
    }
    fclose( fi ); fclose( ft );
}

int main( int argc, char* argv[] ) {
	if ( argc < 6 ) {
		printf("Usage: reclog_train.rdx reclog_test.ridx reclog_train.tm reclog_test.tm output\n");
		return -1;
	}
    fill( user_hit , user_hit  + num_users, 0 );
    fill( user_miss, user_miss + num_users, 0 );
    fill( user_last, user_last + num_users, 0 );
    update( argv[1], argv[3] );
    update( argv[2], argv[4] );
    
    FILE *fo = fopen_check( argv[5], "w" );
    for( int i = 0; i < num_users; i ++ ){
        fprintf( fo, "%d\t%d\t%d\n", i, user_hit[i], user_miss[i] );
    }
    fclose( fo );
	return 0;
}
