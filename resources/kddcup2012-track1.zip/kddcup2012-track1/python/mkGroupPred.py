# import numpypy
import sys
from math import *

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print 'usage: <pred.in> <ufilter> <pred.out>'
        sys.exit(1)

    fi = open( sys.argv[1], 'r' )
    fp = open( sys.argv[2], 'r' )
    fo = open( sys.argv[3], 'w' )
    for line in fp:
        if int( line ) == 0:
            fo.write('0\n')
        else:
            fo.write( fi.readline() )            
    fi.close()
    fp.close()
    fo.close()
