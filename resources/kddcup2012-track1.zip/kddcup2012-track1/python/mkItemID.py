#!/usr/bin/python

import sys

num_items = 6095

def main():
	global num_items
	fi = open(sys.argv[1])
	fo = open(sys.argv[2], 'w')
	if len(sys.argv) > 3:
		num_items = int(sys.argv[3])

	fo.write('%d\n' % num_items)
	for line in fi:
		arr = line.split()
		assert int(arr[1]) < num_items, "item index exceeding limit"
		fo.write('1 %s:1\n' % arr[1])

if __name__ == '__main__':
	if len(sys.argv) < 3:
		print 'usage: input output'
		sys.exit(1)
	else:
		main()
