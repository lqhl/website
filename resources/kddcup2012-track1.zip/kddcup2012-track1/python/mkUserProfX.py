import sys

num_items = 6095
bin_size = 10
bin_size2 = -1
mk_imfb = False
item_mul = num_items

def try_int(s, default_value = -1):
    try:
        return int(s)
    except ValueError:
        return default_value

def load_uprof(uprof_name, ubirth, ugender):
    uprof_file = open(uprof_name)
    for line in uprof_file:
        uid, birth, gender, retweets, keyw = line.split()
        
        uid = try_int(uid)
        birth = try_int(birth)
        gender = try_int(gender)

        if birth >= 1960 and birth <= 2012:
            ubirth[uid] = (birth-1960) / bin_size
            ubirth2[uid] = -1 if bin_size2 < 0 else (birth-1960) / bin_size2
        else:
            ubirth[uid] = -1
            ubirth2[uid] = -1

        if gender >= 0 and gender <= 2:
            ugender[uid] = gender
        else:
            ugender[uid] = -1

    uprof_file.close()

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print "usage: <uprof> <in> <out> [num_items] [bin_size] [bin_size2] [--imfb]"

    if len(sys.argv) > 4:
        num_items = int(sys.argv[4])

    if len(sys.argv) > 5:
        bin_size = int(sys.argv[5])

    if len(sys.argv) > 6:
        bin_size2 = int(sys.argv[6])
        assert bin_size % bin_size2 == 0

    if len(sys.argv) > 7:
        assert sys.argv[7] == '--imfb'
        mk_imfb = True
        item_mul = 1

    ubirth = {}
    ubirth2 = {}
    ugender = {}
    load_uprof(sys.argv[1], ubirth, ugender)

    num_birth_features = max(ubirth.values())+1
    num_birth2_features = 0 if bin_size2 < 0 else num_birth_features * (bin_size / bin_size2)
    num_gender_features = max(ugender.values())+1
    num_uprof_features = num_birth_features * num_gender_features
    num_uprof2_features = num_birth2_features * num_gender_features

    in_file = open(sys.argv[2])
    out_file = open(sys.argv[3], 'w')

    out_file.write('%d\n' % (num_uprof_features * item_mul +
                             num_uprof2_features * item_mul))

    r = bin_size / bin_size2
    last_uid = -1
    for line in in_file:
        uid, iid, result, timestamp = line.split()
        uid = int(uid)
        iid = int(iid)
        assert iid < num_items, "%s: %d" % (line.strip(), iid)

        if not mk_imfb or (mk_imfb and last_uid != uid):
            features = []
            if ubirth[uid] >= 0 and ugender[uid] >= 0:
                ind = num_birth_features * ugender[uid] + ubirth[uid]
                offset = 0 if mk_imfb else iid * num_uprof_features
                features.append((offset + ind, 1))

            if ubirth2[uid] >= 0 and ugender[uid] >= 0:
                offset = 0 if mk_imfb else item_mul * num_uprof_features + iid * num_uprof2_features
                for x in range(0, r):
                    b2 = num_birth2_features * ugender[uid] + r * ubirth[uid] + x
                    v = 1 if x + r * ubirth[uid] == ubirth2[uid] else 0
                    features.append((offset+b2, v))

            out_file.write("%d %s\n" % (len(features), ' '.join(map(lambda f: "%d:%d" % (f[0], f[1]), features))))
        
        last_uid = uid

    in_file.close()
    out_file.close()

    print 'num_birth_features', num_birth_features
    print 'num_birth2_features', num_birth2_features
    print 'num_gender_features', num_gender_features

        

        
    
    
