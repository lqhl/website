import sys

num_items = 6095
user_stat = {}
if __name__ == '__main__':
    if len(sys.argv) != 5:
        print 'usage: <uprof> <sns> <train> <out>'
        sys.exit(1)
        
    for line in open(sys.argv[1]):
        uid, birth, gender, tweets, keyw = line.split()
        uid = int(uid)
        user_stat[uid] = [0, 0, 0]

    for line in open(sys.argv[2]):
        uid, iid = line.split()
        uid, iid = int(uid), int(iid)
        if iid < num_items:
            user_stat[uid][0] += 1

    for line in open(sys.argv[3]):
        uid, iid, rt, t = line.split()
        uid, iid, rt = int(uid), int(iid), int(rt)
        rt = 1 if rt == 1 else 0

        user_stat[uid][rt+1] += 1

    ofile = open(sys.argv[4], "w")
    for u, s in user_stat.iteritems():
        ofile.write("%d %s\n" % (u, ' '.join(map(str, s))))
    ofile.close()
