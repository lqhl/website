# import numpypy
import sys
from math import *

num_users = 2320895
num_items = 6095
num_genders = 3

def load_uapm( fname, minhit = 1 ):
    uapm = {}
    fi = open( fname, 'r' )
    for line in fi:
        arr = line.split()
        if int(arr[2]) < minhit:
            continue
        uid = int( arr[0] )
        apm = float( arr[1] )
        uapm[ uid ] = apm
    fi.close()
    print '%d users with apm' % len(uapm)
    return uapm
    
def write_value( fname, fin, ucat ):
    print 'write to fname=%s' %fname
    fi = open( fin, 'r' )
    fo = open( fname, 'w' )
    last_uid = -1
    fo.write( '1\n' )
    for line in fi:
        uid = int( line.split()[0] )
        if uid != last_uid:
            if uid in ucat:
                fo.write( '1 0:%f\n' % ucat[ uid ] )
            else:
                fo.write( '0\n' )
            last_uid = uid
    fi.close()
    fo.close()

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print 'usage: <user.apm60> <train> <minhit>'
        sys.exit(1)
    minhit = int( sys.argv[3] )    
    uapm = load_uapm( sys.argv[1], minhit )    
    apms = sys.argv[1].split('.')[1]

    write_value( 'features/%s.u%sr%dT' % (sys.argv[2],apms, minhit), sys.argv[2], uapm )
