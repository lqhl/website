# import numpypy
import sys
from math import *

num_users = 2320895
num_items = 6095
num_genders = 3

def try_int(s, default_value = -1):
    try:
        return int(s)
    except ValueError:
        return default_value

def load_uprof( uprof_name ):
    ugender = {}
    utweets = {}
    uage    = {}
    ecnt = 0
    ufile = open( uprof_name )
    for line in ufile:
        uid, birth, gender, tweets, keyw = line.strip().split()
        
        uid, gender = int(uid), int(gender)
        if gender >= 0 and gender <= 2:                    
            if gender != 0:
                ugender[uid] = gender - 1
        else:
            ecnt += 1
        
        utweets[ uid ] = int( tweets )
        
        birth = try_int( birth )
        if birth >= 1960 and birth <= 2012:
            uage[ uid ] = 2012 - birth;
    ufile.close()
    print 'load uprof end, egender=%d' % ecnt
    return uage, ugender, utweets


def write_gender( fname, fin, ucat ):
    fi = open( fin, 'r' )
    fo = open( fname, 'w' )
    last_uid = -1
    fo.write('1\n')
    for line in fi:
        uid = int( line.split()[0] )
        if uid != last_uid:
            if uid in ucat:
                fo.write( '1 0:%d\n' % ucat[ uid ] )
            else:
                fo.write( '0\n' )
            last_uid = uid
    fi.close()
    fo.close()

def write_value( fname, fin, ucat ):
    fi = open( fin, 'r' )
    fo = open( fname, 'w' )
    last_uid = -1
    fo.write( '1\n' )
    for line in fi:
        uid = int( line.split()[0] )
        if uid != last_uid:
            if uid in ucat:
                fo.write( '1 0:%d\n' % ucat[ uid ] )
            else:
                fo.write( '0\n' )
            last_uid = uid
    fi.close()
    fo.close()

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print 'usage: <user_profile> <train>'
        sys.exit(1)
    uage, ugender, utweets = load_uprof( sys.argv[1] )
    write_gender( 'features/%s.ugenderT' % sys.argv[2], sys.argv[2], ugender )
    write_value ( 'features/%s.uageT' % sys.argv[2], sys.argv[2], uage )
    write_value ( 'features/%s.utweetsT' % sys.argv[2], sys.argv[2], utweets )
