import sys

min_time = 1318348785L
max_time = 1321027199L
train_ratio = 0.8
total_rec = 73209277

if __name__ == '__main__':
	split_time = min_time * (1-train_ratio) + max_time * train_ratio
	print 'split_time', split_time
	
	ifile = open('rec_log_train_newlabel.txt')
	train_file = open('train.txt', 'w')
	validation_file = open('test.txt', 'w')
	
	
	print '0% complete',
	sys.stdout.flush()

	for (k, line) in enumerate(ifile):
		t = long(line.split('\t')[3])
		
		
		if t < split_time:
			train_file.write(line)
		else:
			validation_file.write(line)
			
		if k % (total_rec / 100) == 0:
			print '\r%d%% complete' % (k / (total_rec / 100), ),
			sys.stdout.flush()
			
			
	print
	
	ifile.close()
	train_file.close()
	validation_file.close()
		
		
