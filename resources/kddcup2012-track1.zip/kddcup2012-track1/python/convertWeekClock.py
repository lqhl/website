#!/usr/bin/python
import sys
import time

def makeTimeinday( fname, fout ):
        fi = open( fname, 'r' )
        fo = open( fout , 'w' )
        for line in fi:
                fo.write( time.strftime( '%w\t%H:%M:%S\n', time.localtime( float(line.split()[3]) ) ) )
        fi.close()
        fo.close()

def main():
        makeTimeinday( sys.argv[1], sys.argv[2] )

if __name__ == '__main__':
	if len(sys.argv) < 3:
		print 'usage: input output'
		sys.exit(1)
	else:
		main()
