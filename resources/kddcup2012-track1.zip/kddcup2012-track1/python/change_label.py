

def change_label(ifname, ofname):
	ifile = open(ifname)
	ofile = open(ofname, 'w')

	for num, line in enumerate(ifile):
		user, item, rating, timestamp = line.split('\t')
		
		rating = '0' if int(rating) == -1 else '1'
		
		ofile.write('\t'.join((user, item, rating, timestamp)))
		
	
	ifile.close()
	ofile.close()
	
if __name__ == '__main__':
	change_label('rec_log_train.txt', 'rec_log_train_newlabel.txt')
	change_label('rec_log_test.txt', 'rec_log_test_newlabel.txt')
		
		
