#!/usr/bin/python

import sys

def main():
	fi = open(sys.argv[1])
	fo = open(sys.argv[2], 'w')
	fo.write('2400000\n')
	for line in fi:
		arr = line.split()
		fo.write('1 %s:1\n' % arr[0])

if __name__ == '__main__':
	if len(sys.argv) != 3:
		print 'usage: input output'
	else:
		main()
