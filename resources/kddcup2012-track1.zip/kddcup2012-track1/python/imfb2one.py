import sys

if __name__ == '__main__':
	with open(sys.argv[1]) as fi, open(sys.argv[2], 'w') as fo:
		fo.write(fi.readline())
		for line in fi:
			arr = line.split()
			fo.write(arr[0])
			arr = arr[1:]
			for each in arr:
				k, v = each.split(':')
				fo.write(' %s:1' % k)
			fo.write('\n')
