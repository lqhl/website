#!/usr/bin/python

import sys

num_timestamp = 0

def main():
	global num_items
	fi = open(sys.argv[1])
	fo = open(sys.argv[2], 'w')
	if len(sys.argv) > 3:
		num_items = int(sys.argv[3])

	fo.write('%d\n' % 1 )
	for line in fi:
		arr = line.split()
		fo.write('1 0:%s\n' % arr[3])

if __name__ == '__main__':
	if len(sys.argv) < 3:
		print 'usage: input output'
		sys.exit(1)
	else:
		main()
