import sys

def load_catmap( fname, nlev ):
    lst = []
    catmap={}
    fi = open( fname, 'r' )
    ncnt = 0
    for line in fi:
        arr = line.split()
        key = '.'.join( arr[1].split('.')[ 0: nlev ] )
        if not key in catmap:
            catmap[ key ] = len( catmap )
        cid = catmap[ key ]
        lst.append( cid )
        ncnt += 1
    fi.close()    
    print 'level=%d, %d/%d = %f in all' % ( nlev, ncnt, len(catmap), float(ncnt) / len(catmap) )    
    return lst, catmap

# make category map
if len( sys.argv ) < 3:
    print 'Usage:<input> <output>'
    exit( 0 )

num_items = 6095
ncat = [ 1 ]
dt   = [ [ 0 for i in xrange( num_items ) ] ]

for nlev in xrange( 4 ):
    lst,catmap = load_catmap( sys.argv[1], nlev+1 )
    dt.append( lst )
    ncat.append( len(catmap) )
ncat.append( num_items )
dt.append( [ i for i in xrange( num_items )] )

fo = open( sys.argv[2], 'w' )
fo.write( '%d %d\n' % (num_items, len(ncat) ) )
fo.write( ' '.join( [ str(i) for i in ncat ] ) + '\n' )
for i in xrange(num_items):
    fo.write( ' '.join( [ str(dt[j][i])  for j in xrange(len(ncat)) ] ) + '\n' )     
fo.close()

