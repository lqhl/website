import operator

tag_count = {}
with open("user_profile.ridx") as fi, open("tag.stat", 'w') as fo:
	for line in fi:
		tags = map(int, line.split()[4].split(';'))
		for tag in tags:
			if tag in tag_count:
				tag_count[tag] += 1
			else:
				tag_count[tag] = 1

	tag_sorted = sorted(tag_count.iteritems(), key = operator.itemgetter(1), reverse = True)
	i = 0
	for tag, c in tag_sorted:
		fo.write("%d %d %d\n" % (tag, c, i))
		i += 1
