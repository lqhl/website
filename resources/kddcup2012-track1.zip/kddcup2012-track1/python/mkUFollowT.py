# import numpypy
import sys
from math import *

num_users = 2320895
num_items = 6095

def load_ustat( ustat_name ):
    u_stat = {}
    for line in open( ustat_name ):
        arr = line.split()
        u_stat[ int(arr[0]) ] = [ int(item) for item in arr[1:len(arr)] ]
    return u_stat

def write_value( fname, fin, ucat, idx, col = 0 ):
    fi = open( fin, 'r' )
    fo = open( fname, 'w' )
    last_uid = -1
    fo.write('1\n')
    for line in fi:        
        uid = int( line.split()[col] )
        if uid != last_uid:
            if uid in ucat:
                fo.write( '1 0:%d\n' % ucat[ uid ][ idx ] )
            else:
                fo.write( '0\n' )
            last_uid = uid
    fi.close()
    fo.close()

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print 'usage: <user.stat> <train>'
        sys.exit(1)
    u_stat = load_ustat( sys.argv[1] )
    write_value( 'features/%s.ufollowT' % sys.argv[2] , sys.argv[2],u_stat, 0 );

