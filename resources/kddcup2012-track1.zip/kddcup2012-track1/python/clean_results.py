import glob, os, shutil

if __name__ == '__main__':
    init_files = '''
item.txt
run.Makefile
Makefile
preprocessing.Makefile
rec_log_test.txt
rec_log_train.txt
T.buf
T.Makefile
user_action.txt
user_key_word.txt
user_profile.txt
user_sns.txt
clean_results.py
'''
    folders = '''
python
java
cpp
features
T.buf
run
'''


    init_files = init_files.split()
    folders = folders.split()


    for f in glob.glob('*'):
        if not f in folders:
            if not f in init_files:
                os.remove(f)
        elif f == 'cde-package':
            shutil.rmtree(f)
        elif f == 'features':
            shutil.rmtree('features')

    os.mkdir('features')
                
            
