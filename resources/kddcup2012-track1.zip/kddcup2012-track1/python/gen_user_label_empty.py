import sys

num_items = 6095
user_stat = {}
if __name__ == '__main__':
    if len(sys.argv) != 3:
        print 'usage: <uprof> <labelf>'
        sys.exit(1)
        
    for line in open(sys.argv[1]):
        uid, birth, gender, tweets, keyw = line.split()
        uid = int(uid)
        user_stat[uid] = 1

    ofile = open(sys.argv[2], "w")
    for u, s in user_stat.iteritems():
        labels = [0]

        ofile.write("%d %d %s\n" % (u, len(labels), ' '.join(map(str, labels))))
    ofile.close()

        

