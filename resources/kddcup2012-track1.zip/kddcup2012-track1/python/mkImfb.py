#!/usr/bin/python
import sys

if __name__ == '__main__':
	if len(sys.argv) != 3:
		print 'usage: input output'
		exit(1)
	fi = open(sys.argv[1], 'r')
	fo = open(sys.argv[2], 'w')

	last_uid = -1
	count = 0
	for line in fi:
		arr = line.split()
		uid = int(arr[0])
		if uid != last_uid:
			if last_uid != -1:
				fo.write('%d 0\n' % count)
			last_uid = uid
			count = 1
		else:
			count += 1
	
	if last_uid != -1:
		fo.write('%d 0\n' % count)
	
