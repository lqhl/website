#!/bin/bash
# wait till file is ready
waitfile.sh 0070.model
sleep 4m
mv log.txt log.70.txt
./run_more.sh $1
