#!/bin/bash

cd ../..
make purge.group.exp
cd -

conf=$1
start=0
nround=80
testf=../../test.group
test_wlist=../../test.purge.group.filter
trainf=../../train.group
train_wlist=../../train.purge.group.filter
evallogistic=0
evaltrain=0
evaltest=1

source ../train_test.sh 

