rm -f log.txt pred.txt pred0*.txt pred_store 0*.model stat.txt stats.txt pred_train.txt *tmp *~ \#*\# cur_model
