set -e
if [ $# -ne 2 ]
then
    echo 'usage: <conf> <model_num>'
    exit
fi

conf=$1
train_buffer=`python ../../python/extract_conf.py $conf buffer_feature`
test_buffer=`python ../../python/extract_conf.py $conf test:buffer_feature`
echo "train_buffer: $train_buffer"
echo "test_buffer: $test_buffer"

svd_feature_infer $conf buffer_feature=$train_buffer pred=$2 name_pred=train.pred.$2 silent=1
svd_feature_infer $conf test:buffer_feature=$test_buffer pred=$2 name_pred=test.pred.$2 silent=1

