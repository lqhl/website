#!/bin/bash
set -e

if [ $# -ne 1 ]; then
	echo "Usage: <conf>"
	exit 1
fi

cd ../..
make itemf.cat1234
make purge.group.uprofx62.star2000.uproftag.uaction.sns_train.ukey.imfb.h24.exp
cd -

conf=$1
start=0
nround=40
testf=../../test.group
test_wlist=../../test.purge.group.filter
trainf=../../train.group
train_wlist=../../train.purge.group.filter
evallogistic=0
evaltrain=0
evaltest=1

source ../train_test.sh 

