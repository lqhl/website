#!/bin/bash

# wait till file is ready
waitfile.sh ../6.uprofx62.star2000.uproftag.uaction.sns_train.ukey.imfb.icat.h24.reg.decay/0037.model
cd ../6.uprofx62.star2000.uproftag.uaction.sns_train.ukey.imfb.icat.h24.reg.decay
../pred_traintest.sh uprofx62.star2000.uproftag.uaction.sns.ukey.imfb.icat.h24.reg.decay.l02d09m05.2.conf 37
cd -
./run.sh $1
