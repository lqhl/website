#!/bin/bash

cd ../..
make -f T.Makefile item.taxall
T.buf/mkbuf.sh RKDX.T.uprof.tm.uact.cath23.tagx1
cd -

conf=$1
start=0
nround=40
testf=../../test.group
test_wlist=../../test.purge.group.filter
trainf=../../train.group
train_wlist=../../train.purge.group.filter

evallogistic=0
evaltrain=0
evaltest=1

post_view=0
eval_offset=1

source ../train_test.sh 

