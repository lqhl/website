#!/bin/bash 
conf=$1
testbuf=`python ../../python/extract_conf.py $conf test:buffer_feature`
trainbuf=`python ../../python/extract_conf.py $conf buffer_feature`
echo "train_buffer: $trainbuf"

svd_feature_infer $conf test:buffer_feature=$trainbuf pred=$2 name_pred=train.pred.$2
svd_feature_infer $conf pred=$2 name_pred=test.pred.$2
