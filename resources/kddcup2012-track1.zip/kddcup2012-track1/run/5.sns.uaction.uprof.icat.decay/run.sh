#!/bin/bash

cd ../../
make purge.group.uprofx62.uaction.sns_train.imfb.exp
make itemf.cat1234
cd -

conf=$1
start=0
nround=40
testf=../../test.group
test_wlist=../../test.purge.group.filter
trainf=../../train.group
train_wlist=../../train.purge.group.filter
evallogistic=0
evaltrain=0
evaltest=1
save_pred=1

source ../train_test.sh 

