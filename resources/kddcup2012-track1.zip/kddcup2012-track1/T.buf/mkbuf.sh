#!/bin/bash 
set -e
pypy T.buf/genMakeT.py T.buf/$1.conf $1 T.Makefile > $1.mk
make -f $1.mk train.purge.group.$1.buffer test.purge.group.$1.buffer
rm -rf $1.mk

